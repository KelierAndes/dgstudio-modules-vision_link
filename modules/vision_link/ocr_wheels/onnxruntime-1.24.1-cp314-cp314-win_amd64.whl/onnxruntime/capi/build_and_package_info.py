package_name = 'onnxruntime'
__version__ = '1.24.1'
